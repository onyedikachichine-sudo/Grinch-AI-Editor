# Grinch AI Editor (Android starter)

A native Android Studio project for an AI-assisted anime video editing app, using Kotlin, Jetpack Compose and AndroidX Media3.

## Included in v0.1.0
- Blue-and-black editor UI
- Import a video from Android storage using the system document picker
- Preview and play/pause the selected clip
- Select anime effect presets and adjust a session-only intensity value
- Generate basic rule-based editing suggestions for an imported clip

## Not included yet
This is a working starter project, not a finished CapCut replacement. Effects are currently UI presets and are not baked into the video. There is no rendered export, beat detection, multi-track timeline, AI model connection, or music library yet.

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync complete.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

The project uses JDK 17 and Gradle/Android Gradle Plugin versions declared in the project files.

## Next development milestones
1. Add a real timeline with clip trimming and multiple clips.
2. Add audio import and beat analysis.
3. Implement GPU/video effects and render/export (Media3 Transformer or another compatible media pipeline).
4. Add optional AI-assisted scene selection and caption generation.
5. Add export presets such as 720p and 1080p.
