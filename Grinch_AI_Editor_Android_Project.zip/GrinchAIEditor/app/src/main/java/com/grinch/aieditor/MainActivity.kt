package com.grinch.aieditor

import android.net.Uri
import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF070B13)
private val Panel = Color(0xFF111A2A)
private val Blue = Color(0xFF2589FF)
private val Cyan = Color(0xFF57D7FF)
private val Muted = Color(0xFF91A3BC)

class MainActivity : ComponentActivity() {
    private var selectedVideo by mutableStateOf<Uri?>(null)
    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            selectedVideo = it
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Blue, secondary = Cyan, background = Ink,
                    surface = Panel, onBackground = Color.White, onSurface = Color.White
                )
            ) {
                EditorScreen(
                    videoUri = selectedVideo,
                    onImport = { videoPicker.launch(arrayOf("video/*")) }
                )
            }
        }
    }
}

@Composable
private fun EditorScreen(videoUri: Uri?, onImport: () -> Unit) {
    var activeEffect by remember { mutableStateOf("Glow") }
    var intensity by remember { mutableFloatStateOf(0.65f) }
    var aiNotes by remember { mutableStateOf("Import a clip to get editing suggestions.") }

    Column(
        modifier = Modifier.fillMaxSize().background(Ink)
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("GRINCH", color = Color.White, fontSize = 25.sp)
                Text("AI EDITOR  •  ANIME STUDIO", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
            }
            Surface(color = Color(0xFF102B4B), shape = RoundedCornerShape(50)) {
                Text("BETA", color = Cyan, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp), fontSize = 11.sp)
            }
        }

        // Video preview
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier.fillMaxWidth().height(250.dp)
                    .background(Color(0xFF0C1422)),
                contentAlignment = Alignment.Center
            ) {
                if (videoUri != null) {
                    VideoPreview(uri = videoUri)
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PlayArrow, null, tint = Blue, modifier = Modifier.size(54.dp))
                        Text("YOUR ANIME PREVIEW", color = Color.White, fontSize = 14.sp)
                        Text("Import a video to start editing", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }

        Button(
            onClick = onImport,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Blue),
            shape = RoundedCornerShape(15.dp)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text(if (videoUri == null) "IMPORT ANIME CLIP" else "CHANGE VIDEO")
        }

        SectionTitle("AI EDITING ASSISTANT", Icons.Default.AutoAwesome)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Editing direction", color = Muted, fontSize = 12.sp)
                Text("Make it a high-energy anime edit with beat cuts, blue glow and smooth transitions.", color = Color.White)
                Button(
                    onClick = {
                        aiNotes = if (videoUri == null) {
                            "Import a clip first. Then I can help you plan the edit."
                        } else {
                            "Suggested edit: start with a 1-second hook, cut on music beats, use a short zoom transition, add blue glow to the highlight, then finish with a slow-motion outro. These are suggestions—not an automatic render yet."
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF173B66))
                ) {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(7.dp))
                    Text("GENERATE EDITING IDEAS")
                }
                Text(aiNotes, color = Cyan, fontSize = 12.sp)
            }
        }

        SectionTitle("EFFECT PRESETS", Icons.Default.Tune)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            listOf("Glow", "Shake", "Motion blur", "Flash", "Slow motion").forEach { effect ->
                FilterChip(
                    selected = activeEffect == effect,
                    onClick = { activeEffect = effect },
                    label = { Text(effect) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF164A82),
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$activeEffect intensity", modifier = Modifier.weight(1f), color = Color.White)
                    Text("${(intensity * 100).toInt()}%", color = Cyan)
                }
                Slider(value = intensity, onValueChange = { intensity = it }, colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Blue))
                Text("Preset selection is saved in this editing session. Applying and rendering visual effects is planned for the next build.", color = Muted, fontSize = 11.sp)
            }
        }

        SectionTitle("AUDIO & TIMELINE", Icons.Default.MusicNote)
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, null, tint = Cyan)
                    Spacer(Modifier.width(8.dp))
                    Text("Music / beat sync", color = Color.White)
                }
                Text("Add music and beat detection will be added in a later version.", color = Muted, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ContentCut, null, tint = Cyan)
                    Spacer(Modifier.width(8.dp))
                    Text("Clip trimming & multi-layer timeline", color = Color.White)
                }
                Text("Planned for the next editing milestone.", color = Muted, fontSize = 12.sp)
            }
        }

        OutlinedButton(
            onClick = { aiNotes = "Export is not available in this starter build yet. The current version imports and previews video and provides edit planning." },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Blue),
            shape = RoundedCornerShape(14.dp)
        ) { Text("EXPORT VIDEO  •  COMING NEXT", color = Cyan) }

        Text("GRINCH AI EDITOR • VERSION 0.1.0", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun VideoPreview(uri: Uri) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
        update = { it.player = player },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun SectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(19.dp))
        Text(title, color = Color.White, fontSize = 13.sp, letterSpacing = 1.2.sp)
    }
}
